﻿namespace ExtraaEdgePhoneService.Models
{
    public class MonthlyReport
    {
        public int TotalPhoneSold { get; set; }
        public int? TotalSellingPrice { get; set; }
        public int? TotalProfitAmount { get; set; }
    }

    public class MonthlyReportByProfitAndLoss
    {
        public int TotalPhoneSold { get; set; }
        public int? TotalSellingPrice { get; set; }
        public int? TotalProfitAmount { get; set; }
        public string? DateRange { get; set; }
    }

    public class MonthlyReportByProfitAndLossVM
    {
        public List<MonthlyReportByProfitAndLoss>? monthlyReportsList { get; set; }
        public string? ProfitOrLoss { get; set; }
        public int? ProfitOrLossAmount { get; set; }
    }
}
