﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ExtraaEdgePhoneService.Models
{
    public partial class TblPhone
    {
        [ScaffoldColumn(false)]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int PhoneId { get; set; }
        [Required]
        public string BrandName { get; set; } = null!;
        [Required]
        public string ModelName { get; set; } = null!;
        public int PurchasePrice { get; set; }
        public int SellingPrice { get; set; }
        public DateTime? CreatedDate { get; set; }
    }
}
