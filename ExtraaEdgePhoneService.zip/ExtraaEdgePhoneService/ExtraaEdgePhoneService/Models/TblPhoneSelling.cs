﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ExtraaEdgePhoneService.Models
{
    public partial class TblPhoneSelling
    {
        [ScaffoldColumn(false)]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int SellingId { get; set; }
        public int PhoneId { get; set; }
        public int Quantity { get; set; }
        public int OriginalPrice { get; set; }
        public int DiscountPercent { get; set; }        
        public int? DiscountedPrice { get; set; }        
        public int? TotalSellingPrice { get; set; }
        public DateTime? CreatedDate { get; set; }
    }
}
