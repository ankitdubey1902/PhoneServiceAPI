﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace ExtraaEdgePhoneService.Models
{
    public partial class ExtraaedgeContext : DbContext
    {
        public ExtraaedgeContext()
        {
        }

        public ExtraaedgeContext(DbContextOptions<ExtraaedgeContext> options)
            : base(options)
        {
        }

        public virtual DbSet<TblPhone> TblPhones { get; set; } = null!;
        public virtual DbSet<TblPhoneSelling> TblPhoneSellings { get; set; } = null!;

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
          
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<TblPhone>(entity =>
            {
                entity.HasKey(e => e.PhoneId)
                    .HasName("PK__TblPhone__F3EE4BB045DAD4E4");

                entity.ToTable("TblPhone");

                entity.Property(e => e.BrandName).HasMaxLength(50);

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("date")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.ModelName).HasMaxLength(50);
            });

            modelBuilder.Entity<TblPhoneSelling>(entity =>
            {
                entity.HasKey(e => e.SellingId)
                    .HasName("PK__TblPhone__4706784FB2728A43");

                entity.ToTable("TblPhoneSelling");

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("date")
                    .HasDefaultValueSql("(getdate())");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
