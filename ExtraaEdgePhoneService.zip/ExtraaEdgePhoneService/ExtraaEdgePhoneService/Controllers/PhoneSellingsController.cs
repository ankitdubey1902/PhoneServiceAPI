﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ExtraaEdgePhoneService.Models;

namespace ExtraaEdgePhoneService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PhoneSellingsController : ControllerBase
    {
        private readonly ExtraaedgeContext _context;

        public PhoneSellingsController(ExtraaedgeContext context)
        {
            _context = context;
        }

        // GET: api/PhoneSellings
        [HttpGet]
        public async Task<ActionResult<IEnumerable<TblPhoneSelling>>> GetTblPhoneSellings()
        {
            if (_context.TblPhoneSellings == null)
            {
                return NotFound();
            }
            return await _context.TblPhoneSellings.ToListAsync();
        }

        // GET: api/PhoneSellings/5
        [HttpGet("{id}")]
        public async Task<ActionResult<TblPhoneSelling>> GetTblPhoneSelling(int id)
        {
            if (_context.TblPhoneSellings == null)
            {
                return NotFound();
            }
            var tblPhoneSelling = await _context.TblPhoneSellings.FindAsync(id);

            if (tblPhoneSelling == null)
            {
                return NotFound();
            }

            return tblPhoneSelling;
        }

        // PUT: api/PhoneSellings/5        
        [HttpPut("{id}")]
        public async Task<IActionResult> PutTblPhoneSelling(int id, TblPhoneSelling tblPhoneSelling)
        {
            if (id != tblPhoneSelling.SellingId)
            {
                return BadRequest();
            }
            var OgPrice = (from s in _context.TblPhones where s.PhoneId == tblPhoneSelling.PhoneId select s.SellingPrice).FirstOrDefault();
            if (OgPrice == 0)
            {
                return Problem("Entity set 'ExtraaedgeContext.TblPhoneSellings'  is null.");
            }
            else
            {
                tblPhoneSelling.OriginalPrice = OgPrice;
                tblPhoneSelling.DiscountedPrice = (tblPhoneSelling.OriginalPrice - (tblPhoneSelling.OriginalPrice * tblPhoneSelling.DiscountPercent / 100));
                tblPhoneSelling.TotalSellingPrice = (tblPhoneSelling.DiscountedPrice * tblPhoneSelling.Quantity);

                _context.Entry(tblPhoneSelling).State = EntityState.Modified;

                try
                {
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!TblPhoneSellingExists(id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }

                return NoContent();
            }
        }

        // POST: api/PhoneSellings
        [HttpPost]
        public async Task<ActionResult<TblPhoneSelling>> PostTblPhoneSelling(TblPhoneSelling tblPhoneSelling)
        {
            if (_context.TblPhoneSellings == null)
            {
                return Problem("Entity set 'ExtraaedgeContext.TblPhoneSellings'  is null.");
            }
            var OgPrice = (from s in _context.TblPhones where s.PhoneId == tblPhoneSelling.PhoneId select s.SellingPrice).FirstOrDefault();
            if (OgPrice == 0)
            {
                return Problem("Entity set 'ExtraaedgeContext.TblPhoneSellings'  is null.");
            }
            else
            {
                tblPhoneSelling.OriginalPrice = OgPrice;
                tblPhoneSelling.DiscountedPrice = (tblPhoneSelling.OriginalPrice - (tblPhoneSelling.OriginalPrice * tblPhoneSelling.DiscountPercent / 100));
                tblPhoneSelling.TotalSellingPrice = (tblPhoneSelling.DiscountedPrice * tblPhoneSelling.Quantity);

                _context.TblPhoneSellings.Add(tblPhoneSelling);
                await _context.SaveChangesAsync();

                return CreatedAtAction("GetTblPhoneSelling", new { id = tblPhoneSelling.SellingId }, tblPhoneSelling);
            }
        }

        // DELETE: api/PhoneSellings/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteTblPhoneSelling(int id)
        {
            if (_context.TblPhoneSellings == null)
            {
                return NotFound();
            }
            var tblPhoneSelling = await _context.TblPhoneSellings.FindAsync(id);
            if (tblPhoneSelling == null)
            {
                return NotFound();
            }

            _context.TblPhoneSellings.Remove(tblPhoneSelling);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool TblPhoneSellingExists(int id)
        {
            return (_context.TblPhoneSellings?.Any(e => e.SellingId == id)).GetValueOrDefault();
        }
    }
}
