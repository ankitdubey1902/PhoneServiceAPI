﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ExtraaEdgePhoneService.Models;

namespace ExtraaEdgePhoneService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PhonesController : ControllerBase
    {
        private readonly ExtraaedgeContext _context;

        public PhonesController(ExtraaedgeContext context)
        {
            _context = context;
        }

        // GET: api/Phones
        [HttpGet]
        public async Task<ActionResult<IEnumerable<TblPhone>>> GetTblPhones()
        {
          if (_context.TblPhones == null)
          {
              return NotFound();
          }
            return await _context.TblPhones.ToListAsync();
        }

        // GET: api/Phones/5
        [HttpGet("{id}")]
        public async Task<ActionResult<TblPhone>> GetTblPhone(int id)
        {
          if (_context.TblPhones == null)
          {
              return NotFound();
          }
            var tblPhone = await _context.TblPhones.FindAsync(id);

            if (tblPhone == null)
            {
                return NotFound();
            }

            return tblPhone;
        }

        // PUT: api/Phones/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutTblPhone(int id, TblPhone tblPhone)
        {
            if (id != tblPhone.PhoneId)
            {
                return BadRequest();
            }

            _context.Entry(tblPhone).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!TblPhoneExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Phones
        [HttpPost]
        public async Task<ActionResult<TblPhone>> PostTblPhone(TblPhone tblPhone)
        {
          if (_context.TblPhones == null)
          {
              return Problem("Entity set 'ExtraaedgeContext.TblPhones'  is null.");
          }
            _context.TblPhones.Add(tblPhone);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetTblPhone", new { id = tblPhone.PhoneId }, tblPhone);
        }

        // DELETE: api/Phones/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteTblPhone(int id)
        {
            if (_context.TblPhones == null)
            {
                return NotFound();
            }
            var tblPhone = await _context.TblPhones.FindAsync(id);
            if (tblPhone == null)
            {
                return NotFound();
            }

            _context.TblPhones.Remove(tblPhone);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool TblPhoneExists(int id)
        {
            return (_context.TblPhones?.Any(e => e.PhoneId == id)).GetValueOrDefault();
        }
    }
}
