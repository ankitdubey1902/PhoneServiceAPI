﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ExtraaEdgePhoneService.Models;
using Newtonsoft.Json.Linq;

namespace ExtraaEdgePhoneService.Controllers
{

    [ApiController]
    public class PhonesReportController : ControllerBase
    {
        private readonly ExtraaedgeContext _context;

        public PhonesReportController(ExtraaedgeContext context)
        {
            _context = context;
        }
        // GET: api/GetMonthlyReport/2022-05-01/2022-05-30
        [HttpGet]
        [Route("api/GetMonthlyReport/{frmDate}/{toDate}")]
        public List<MonthlyReport>? GetMonthlyReport(DateTime frmDate, DateTime toDate)
        {
            var result = from p in _context.TblPhones
                         join s in _context.TblPhoneSellings on p.PhoneId equals s.PhoneId
                         where (s.CreatedDate >= frmDate && s.CreatedDate <= toDate)
                         select new { p.PurchasePrice, s.TotalSellingPrice, s.Quantity } into tbl
                         group tbl by 0 into g
                         select new
                         {
                             TotalPhoneSold = g.Sum(x => x.Quantity),
                             TotalSellingPrice = g.Sum(x => x.TotalSellingPrice),
                             TotalProfitAmount = g.Sum(x => x.TotalSellingPrice - (x.PurchasePrice * x.Quantity)),
                         };

            var sresponse = Newtonsoft.Json.JsonConvert.SerializeObject(result);
            MonthlyReport monthlyReport = new MonthlyReport();
            var response = Newtonsoft.Json.JsonConvert.DeserializeObject<List<MonthlyReport>>(sresponse);

            return response;
        }
        // GET: api/GetMonthlyReportByBrandName/2022-06-01/2022-06-30/MI
        [HttpGet]
        [Route("api/GetMonthlyReportByBrandName/{frmDate}/{toDate}/{brandName}")]
        public List<MonthlyReport>? GetMonthlyReport(DateTime frmDate, DateTime toDate, string brandName)
        {
            var result = from p in _context.TblPhones
                         join s in _context.TblPhoneSellings on p.PhoneId equals s.PhoneId
                         where (s.CreatedDate >= frmDate && s.CreatedDate <= toDate && p.BrandName == brandName)
                         select new { p.PurchasePrice, s.TotalSellingPrice, s.Quantity } into tbl
                         group tbl by 0 into g
                         select new
                         {
                             TotalPhoneSold = g.Sum(x => x.Quantity),
                             TotalSellingPrice = g.Sum(x => x.TotalSellingPrice),
                             TotalProfitAmount = g.Sum(x => x.TotalSellingPrice - (x.PurchasePrice * x.Quantity)),
                         };

            var sresponse = Newtonsoft.Json.JsonConvert.SerializeObject(result);
            MonthlyReport monthlyReport = new MonthlyReport();
            var response = Newtonsoft.Json.JsonConvert.DeserializeObject<List<MonthlyReport>>(sresponse);

            return response;
        }

        // GET: api/GetMonthlyReportByProfitAndLoss/2022-06-01/2022-06-30/MI
        [HttpGet]
        [Route("api/GetMonthlyReportByProfitAndLoss/{frmDate1}/{toDate1}/{frmDate2}/{toDate2}")]
        public MonthlyReportByProfitAndLossVM GetMonthlyReportByProfitAndLoss(DateTime frmDate1, DateTime toDate1, DateTime frmDate2, DateTime toDate2)
        {
            var value1 = (from p in _context.TblPhones
                          join s in _context.TblPhoneSellings on p.PhoneId equals s.PhoneId
                          where (s.CreatedDate >= frmDate1 && s.CreatedDate <= toDate1)
                          select new { p.PurchasePrice, s.TotalSellingPrice, s.Quantity } into tbl
                          group tbl by 0 into g
                          select new
                          {
                              TotalPhoneSold = g.Sum(x => x.Quantity),
                              TotalSellingPrice = g.Sum(x => x.TotalSellingPrice),
                              TotalProfitAmount = g.Sum(x => x.TotalSellingPrice - (x.PurchasePrice * x.Quantity)),
                              DateRange = "'From Date - " + frmDate1 + " To Date - " + toDate1 + "'"
                          }).ToList();

            var value2 = (from p in _context.TblPhones
                          join s in _context.TblPhoneSellings on p.PhoneId equals s.PhoneId
                          where (s.CreatedDate >= frmDate2 && s.CreatedDate <= toDate2)
                          select new { p.PurchasePrice, s.TotalSellingPrice, s.Quantity } into tbl
                          group tbl by 0 into g
                          select new
                          {
                              TotalPhoneSold = g.Sum(x => x.Quantity),
                              TotalSellingPrice = g.Sum(x => x.TotalSellingPrice),
                              TotalProfitAmount = g.Sum(x => x.TotalSellingPrice - (x.PurchasePrice * x.Quantity)),
                              DateRange = "'From Date - " + frmDate2 + " To Date - " + toDate2 + "'"
                          }).ToList();

            int? profitAmount1 = value1.FirstOrDefault().TotalProfitAmount;
            int? profitAmount2 = value2.FirstOrDefault().TotalProfitAmount;
            string ProfitOrLoss = string.Empty;
            int? ProfitOrLossAmount = 0;
            string sProfitOrLossAmount = string.Empty;
            if (profitAmount2 > profitAmount1)
            {
                ProfitOrLossAmount = profitAmount2 - profitAmount1;
                ProfitOrLoss = "Profit";
            }
            else if (profitAmount2 < profitAmount1)
            {
                ProfitOrLossAmount = profitAmount1 - profitAmount2;
                ProfitOrLoss = "Loss";
            }
            

            var result = value1.Concat(value2);
            string sresponse = Newtonsoft.Json.JsonConvert.SerializeObject(result);
            List<MonthlyReportByProfitAndLoss> monthlyReportByProfitAndLoss = new List<MonthlyReportByProfitAndLoss>();
            var response = Newtonsoft.Json.JsonConvert.DeserializeObject<List<MonthlyReportByProfitAndLoss>>(sresponse);

            MonthlyReportByProfitAndLossVM monthlyReportByProfitAndLossVM = new MonthlyReportByProfitAndLossVM();
            foreach (var report in response)
            {
                monthlyReportByProfitAndLoss.Add(report);
            }
            monthlyReportByProfitAndLossVM.monthlyReportsList = monthlyReportByProfitAndLoss;
            monthlyReportByProfitAndLossVM.ProfitOrLoss = ProfitOrLoss;
            monthlyReportByProfitAndLossVM.ProfitOrLossAmount = ProfitOrLossAmount;

            return monthlyReportByProfitAndLossVM;
        }
    }
}
