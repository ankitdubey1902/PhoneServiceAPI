Create database Extraaedge

USE [Extraaedge]
GO

CREATE TABLE TblPhone
(
	[PhoneId] [int] IDENTITY(1,1) NOT NULL PRIMARY KEY,
	[BrandName] [nvarchar](50) NOT NULL,
	[ModelName] [nvarchar](50) NOT NULL,
	[PurchasePrice] [int] NOT NULL,
	[SellingPrice] [int] NOT NULL,
	[CreatedDate] [date] NULL Default(Getdate())
)

CREATE TABLE TblPhoneSelling	
(
	[SellingId] [int] IDENTITY(1,1) NOT NULL PRIMARY KEY,
	[PhoneId] [int] NOT NULL,
	[Quantity] [int] NOT NULL,
	[OriginalPrice] [int] NOT NULL,
	[DiscountPercent] [int] NOT NULL CHECK([DiscountPercent] <= 100),
	[DiscountedPrice] [int] NULL,
	[TotalSellingPrice] [int] NULL,	
	[CreatedDate] [date] NULL Default(Getdate())
)


